Here is where your spec/explanation to the tinychat backend developer goes.
